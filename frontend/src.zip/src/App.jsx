import { useState } from "react";
import "./App.css";

import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import AgentControlCenter from "./components/AgentControlCenter";
import AgentDetail from "./components/AgentDetail";
import Results from "./components/Results";

function App() {
  const [page, setPage] = useState("dashboard");
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [pipelineData, setPipelineData] = useState(null);

  const openAgent = (agent) => {
    setSelectedAgent(agent);
    setPage("agent");
  };

  const backToAgents = () => {
    setSelectedAgent(null);
    setPage("agents");
  };

  return (
    <div className="app">

      <Header />

      <div className="app-layout">

        <Sidebar
          page={page}
          setPage={setPage}
        />

        <main className="main-content">

          {page === "dashboard" && (
            <Dashboard
              setPage={setPage}
              pipelineData={pipelineData}
              setPipelineData={setPipelineData}
            />
          )}

          {page === "agents" && (
            <AgentControlCenter
              openAgent={openAgent}
            />
          )}

          {page === "agent" && selectedAgent && (
            <AgentDetail
              agent={selectedAgent}
              backToAgents={backToAgents}
              pipelineData={pipelineData}
            />
          )}

          {page === "results" && (
            <Results
              pipelineData={pipelineData}
            />
          )}

        </main>

      </div>

    </div>
  );
}

export default App;