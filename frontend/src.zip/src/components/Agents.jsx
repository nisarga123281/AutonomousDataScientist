
import React, { useState } from "react";
import "./Agents.css";

const AGENTS = [
  {
    id: "01",
    name: "Profiling",
    title: "Profiling Agent",
    icon: "◉",
    description:
      "Analyzes the uploaded dataset structure, schema, data types, missing values and duplicate records.",
    output: "Dataset Profile",
    tasks: [
      "Detect dataset dimensions",
      "Identify numerical columns",
      "Identify categorical columns",
      "Analyze data types",
      "Detect missing values",
      "Detect duplicate records",
    ],
  },
  {
    id: "02",
    name: "Cleaning",
    title: "Cleaning Agent",
    icon: "✦",
    description:
      "Automatically cleans the dataset by removing duplicates and handling missing values.",
    output: "Clean Dataset",
    tasks: [
      "Detect missing values",
      "Remove duplicate records",
      "Fill numerical missing values",
      "Fill categorical missing values",
      "Validate cleaned dataset",
      "Save cleaned dataset",
    ],
  },
  {
    id: "03",
    name: "EDA",
    title: "EDA Agent",
    icon: "⌁",
    description:
      "Performs exploratory data analysis to understand distributions, statistics and relationships.",
    output: "EDA Results",
    tasks: [
      "Calculate descriptive statistics",
      "Calculate mean and median",
      "Calculate minimum and maximum",
      "Analyze standard deviation",
      "Calculate correlations",
      "Identify unique values",
    ],
  },
  {
    id: "04",
    name: "Modeling",
    title: "Modeling Agent",
    icon: "◇",
    description:
      "Automatically trains and evaluates a machine learning model using suitable numerical features.",
    output: "ML Model",
    tasks: [
      "Select numerical features",
      "Select prediction target",
      "Split training and testing data",
      "Train Linear Regression model",
      "Calculate MAE and RMSE",
      "Calculate R² model score",
    ],
  },
  {
    id: "05",
    name: "Visualization",
    title: "Visualization Agent",
    icon: "▥",
    description:
      "Generates interactive visualizations that help users understand the dataset.",
    output: "Interactive Charts",
    tasks: [
      "Generate distribution charts",
      "Generate relationship charts",
      "Generate correlation heatmap",
      "Generate box plots",
      "Detect visual outliers",
      "Create Plotly HTML charts",
    ],
  },
  {
    id: "06",
    name: "AI Insights",
    title: "AI Insights Agent",
    icon: "✧",
    description:
      "Interprets analytical results and converts statistical findings into understandable insights.",
    output: "AI Insights",
    tasks: [
      "Analyze data quality",
      "Interpret correlations",
      "Identify strong relationships",
      "Interpret model results",
      "Summarize important findings",
      "Generate recommendations",
    ],
  },
  {
    id: "07",
    name: "Report",
    title: "Report Agent",
    icon: "▤",
    description:
      "Combines all pipeline results into a complete automated data science report.",
    output: "Final Report",
    tasks: [
      "Collect profiling results",
      "Collect cleaning results",
      "Collect EDA results",
      "Collect modeling results",
      "Collect AI insights",
      "Generate final report",
    ],
  },
];

function Agents() {
  const [selectedId, setSelectedId] = useState("01");

  const selectedAgent =
    AGENTS.find((agent) => agent.id === selectedId) || AGENTS[0];

  return (
    <section className="agents-page">

      {/* =====================================================
          PAGE HEADER
      ====================================================== */}

      <div className="agents-page-header">

        <div>
          <div className="agents-eyebrow">
            AUTODS INTELLIGENCE
          </div>

          <h1>Agent Control Center</h1>

          <p>
            Monitor, inspect and understand every autonomous agent
            responsible for the AutoDS data science workflow.
          </p>
        </div>

        <div className="agents-system-status">
          <span className="online-indicator"></span>

          <div>
            <strong>ALL SYSTEMS OPERATIONAL</strong>
            <span>7 autonomous agents online</span>
          </div>
        </div>

      </div>


      {/* =====================================================
          CONTROL CENTER
      ====================================================== */}

      <div className="agents-control-center">

        {/* ===================================================
            LEFT AGENT NAVIGATION
        ==================================================== */}

        <aside className="agents-navigation">

          <div className="agents-navigation-header">
            <span>WORKFLOW</span>
            <strong>7 AGENTS</strong>
          </div>


          <div className="agents-navigation-list">

            {AGENTS.map((agent) => {

              const isActive =
                selectedId === agent.id;

              return (
                <button
                  key={agent.id}
                  type="button"
                  className={`agent-navigation-item ${
                    isActive ? "agent-navigation-active" : ""
                  }`}
                  onClick={() => setSelectedId(agent.id)}
                >

                  <span className="navigation-number">
                    {agent.id}
                  </span>

                  <span className="navigation-icon">
                    {agent.icon}
                  </span>

                  <span className="navigation-text">

                    <strong>
                      {agent.name}
                    </strong>

                    <small>
                      AGENT {agent.id}
                    </small>

                  </span>

                  <span className="navigation-check">
                    ✓
                  </span>

                </button>
              );
            })}

          </div>


          {/* ORCHESTRATOR */}

          <div className="orchestrator">

            <div className="orchestrator-symbol">
              A
            </div>

            <div className="orchestrator-content">

              <small>
                ORCHESTRATOR
              </small>

              <strong>
                AutoDS Controller
              </strong>

            </div>

            <span className="orchestrator-online">
              ONLINE
            </span>

          </div>

        </aside>


        {/* ===================================================
            AGENT DETAILS
        ==================================================== */}

        <main className="agent-details">

          {/* HEADER */}

          <div className="agent-details-header">

            <div className="agent-large-icon">
              {selectedAgent.icon}
            </div>

            <div className="agent-details-title">

              <span className="agent-id">
                AGENT {selectedAgent.id}
              </span>

              <h2>
                {selectedAgent.title}
              </h2>

              <p>
                {selectedAgent.description}
              </p>

            </div>

            <div className="agent-completed">

              <span className="online-indicator"></span>

              COMPLETED

            </div>

          </div>


          {/* METRICS */}

          <div className="agent-metrics">

            <div className="agent-metric">

              <span>STATUS</span>

              <strong className="success-text">
                Operational
              </strong>

              <small>
                Agent completed successfully
              </small>

            </div>

            <div className="agent-metric">

              <span>OUTPUT</span>

              <strong>
                {selectedAgent.output}
              </strong>

              <small>
                Generated by this agent
              </small>

            </div>

            <div className="agent-metric">

              <span>PIPELINE</span>

              <strong>
                Stage {selectedAgent.id}
              </strong>

              <small>
                Autonomous workflow
              </small>

            </div>

          </div>


          {/* RESPONSIBILITIES */}

          <div className="agent-section">

            <div className="agent-section-heading">

              <div className="heading-number">
                01
              </div>

              <div>
                <h3>
                  Agent Responsibilities
                </h3>

                <p>
                  Operations performed during this stage
                </p>
              </div>

            </div>


            <div className="responsibilities">

              {selectedAgent.tasks.map(
                (task, index) => (

                  <div
                    className="responsibility-item"
                    key={task}
                  >

                    <span className="task-number">
                      {String(index + 1).padStart(2, "0")}
                    </span>

                    <span className="task-name">
                      {task}
                    </span>

                    <span className="task-success">
                      ✓
                    </span>

                  </div>

                )
              )}

            </div>

          </div>


          {/* OUTPUT TERMINAL */}

          <div className="agent-section">

            <div className="agent-section-heading">

              <div className="heading-number">
                02
              </div>

              <div>
                <h3>
                  Agent Output
                </h3>

                <p>
                  Result generated by the selected agent
                </p>
              </div>

            </div>


            <div className="agent-terminal">

              <div className="terminal-top">

                <div className="terminal-controls">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>

                <div className="terminal-name">
                  AUTODS / AGENT-{selectedAgent.id}
                </div>

                <div className="terminal-success">
                  SUCCESS
                </div>

              </div>


              <div className="terminal-content">

                <div className="terminal-row">

                  <span className="terminal-prompt">
                    $
                  </span>

                  <span>
                    agent.execute()
                  </span>

                </div>

                <div className="terminal-row terminal-muted">

                  <span>
                    Processing dataset...
                  </span>

                </div>

                <div className="terminal-row">

                  <span className="terminal-check">
                    ✓
                  </span>

                  <span>
                    {selectedAgent.output} generated successfully
                  </span>

                </div>

                <div className="terminal-row">

                  <span className="terminal-check">
                    ✓
                  </span>

                  <span>
                    Output passed to next pipeline stage
                  </span>

                </div>

              </div>

            </div>

          </div>


          {/* PIPELINE */}

          <div className="agent-flow">

            <div className="flow-title">
              AUTONOMOUS FLOW
            </div>

            <div className="flow-nodes">

              {AGENTS.map((agent, index) => (

                <div
                  key={agent.id}
                  className={`flow-node ${
                    selectedId === agent.id
                      ? "flow-node-active"
                      : ""
                  }`}
                  onClick={() => setSelectedId(agent.id)}
                >

                  <span>
                    {agent.id}
                  </span>

                  {index < AGENTS.length - 1 && (
                    <div className="flow-connector"></div>
                  )}

                </div>

              ))}

            </div>

          </div>

        </main>

      </div>

    </section>
  );
}

export default Agents;
