import { CheckCircle2, Activity } from "lucide-react";

import Profiling from "./Profiling";
import Cleaning from "./Cleaning";
import EDA from "./EDA";
import Modeling from "./Modeling";
import Visualization from "./Visualization";
import Insights from "./Insights";
import Report from "./Report";

function Results({ results }) {

  return (
    <main className="results-section">

      {/* RESULTS HEADER */}
      <div className="results-header">

        <div>
          <span className="section-label">
            ANALYSIS RESULTS
          </span>

          <h2>
            Dataset Analysis Dashboard
          </h2>

          <p>
            AutoDS has completed the complete autonomous
            data science workflow on your dataset.
          </p>
        </div>

        <div className="completed-badge">
          <CheckCircle2 size={18} />
          Pipeline Completed
        </div>

      </div>


      {/* SUMMARY */}
      <div className="summary-grid">

        <div className="summary-card">
          <span>Dataset</span>
          <strong>
            {results.input_file
              ? results.input_file.split(/[\\/]/).pop()
              : "Dataset"}
          </strong>
          <small>Processed successfully</small>
        </div>

        <div className="summary-card">
          <span>Rows</span>
          <strong>
            {results.profiling?.rows ??
              results.phase1?.rows ??
              "—"}
          </strong>
          <small>Records analyzed</small>
        </div>

        <div className="summary-card">
          <span>Columns</span>
          <strong>
            {results.profiling?.columns ??
              results.phase1?.columns ??
              "—"}
          </strong>
          <small>Variables analyzed</small>
        </div>

        <div className="summary-card">
          <span>Pipeline</span>
          <strong>7 / 7</strong>
          <small>Stages completed</small>
        </div>

      </div>


      {/* PHASE 1 */}
      <Profiling
        data={
          results.profiling ||
          results.phase1
        }
      />


      {/* PHASE 2 */}
      <Cleaning
        data={
          results.cleaning ||
          results.phase2
        }
      />


      {/* PHASE 3 */}
      <EDA
        data={
          results.eda ||
          results.phase3
        }
      />


      {/* PHASE 4 */}
      <Modeling
        data={
          results.modeling ||
          results.phase4
        }
      />


      {/* PHASE 5 */}
      <Visualization
        data={
          results.visualizations ||
          results.phase5
        }
      />


      {/* PHASE 6 */}
      <Insights
        data={
          results.insights ||
          results.phase6
        }
      />


      {/* PHASE 7 */}
      <Report
        data={
          results.report ||
          results.phase7
        }
      />


      {/* FINAL STATUS */}
      <div className="final-status">

        <Activity size={20} />

        <div>
          <strong>
            AutoDS Analysis Complete
          </strong>

          <p>
            Profiling, cleaning, exploratory analysis,
            machine learning, visualization, AI insights
            and reporting have been completed successfully.
          </p>
        </div>

      </div>

    </main>
  );
}

export default Results;
