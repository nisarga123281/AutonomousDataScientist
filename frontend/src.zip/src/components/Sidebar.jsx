import "./Sidebar.css";

function Sidebar({ page, setPage }) {
  return (
    <aside className="sidebar">

      <nav>

        <button
          className={page === "dashboard" ? "active" : ""}
          onClick={() => setPage("dashboard")}
        >
          <span>⌂</span>
          Dashboard
        </button>

        <button
          className={
            page === "agents" || page === "agent"
              ? "active"
              : ""
          }
          onClick={() => setPage("agents")}
        >
          <span>◉</span>
          Agents
        </button>

        <button
          className={page === "results" ? "active" : ""}
          onClick={() => setPage("results")}
        >
          <span>▤</span>
          Results
        </button>

      </nav>

    </aside>
  );
}

export default Sidebar;