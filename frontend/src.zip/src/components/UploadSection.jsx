
import { useState } from "react";
import { runAutoDS } from "../services/api";

function UploadSection({ setPipelineData }) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];

    if (!selectedFile) return;

    if (!selectedFile.name.toLowerCase().endsWith(".csv")) {
      setError("Only CSV files are supported.");
      setFile(null);
      return;
    }

    setError("");
    setFile(selectedFile);
  };

  const handleRun = async () => {
    if (!file) {
      setError("Please upload a CSV file first.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const result = await runAutoDS(file);

      setPipelineData(result);
    } catch (err) {
      setError(
        err?.response?.data?.detail ||
        err?.message ||
        "Failed to run AutoDS."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="upload-section">

      <div className="section-label">
        DATASET
      </div>

      <div className="upload-card">

        <div className="upload-content">

          <div className="upload-icon">
            ↑
          </div>

          <div>
            <h2>Upload Dataset</h2>

            <p>
              Upload a CSV file and let AutoDS automatically
              analyze, clean, model and visualize your data.
            </p>
          </div>

        </div>

        <label className="upload-box">

          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            hidden
          />

          <span className="upload-arrow">
            ↑
          </span>

          <strong>
            Click to upload CSV
          </strong>

          <small>
            Only .csv files are supported
          </small>

        </label>


        {file && (
          <div className="selected-file">

            <div>
              <span className="file-type">
                CSV
              </span>

              <strong>
                {file.name}
              </strong>
            </div>

            <span className="ready">
              Ready
            </span>

          </div>
        )}


        {error && (
          <div className="upload-error">
            {error}
          </div>
        )}


        <button
          className="run-button"
          onClick={handleRun}
          disabled={loading || !file}
        >
          {loading ? "Running AutoDS..." : "Run AutoDS →"}
        </button>

      </div>

    </section>
  );
}

export default UploadSection;
