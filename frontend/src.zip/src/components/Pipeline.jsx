import React from "react";

const stages = [
  ["01", "Profiling", "◉"],
  ["02", "Cleaning", "✓"],
  ["03", "EDA", "⌁"],
  ["04", "Modeling", "◇"],
  ["05", "Visualization", "▥"],
  ["06", "AI Insights", "✦"],
  ["07", "Report", "▤"]
];

function Pipeline({ completed = false }) {
  return (
    <section className="pipeline-section">

      <div className="section-label">
        WORKFLOW
      </div>

      <div className="pipeline-heading">

        <div>
          <h2>Analysis Pipeline</h2>

          <p>
            7 automated stages
          </p>
        </div>

        {completed && (
          <span className="pipeline-complete">
            ✓ All stages completed
          </span>
        )}

      </div>

      <div className="pipeline">

        {stages.map((stage, index) => (

          <React.Fragment key={stage[0]}>

            <div
              className={`pipeline-stage ${
                completed ? "completed" : ""
              }`}
            >

              <div className="stage-icon">
                {completed ? "✓" : stage[2]}
              </div>

              <div className="stage-number">
                {stage[0]}
              </div>

              <div className="stage-name">
                {stage[1]}
              </div>

            </div>

            {index < stages.length - 1 && (
              <div className="pipeline-arrow">
                →
              </div>
            )}

          </React.Fragment>

        ))}

      </div>

    </section>
  );
}

export default Pipeline;