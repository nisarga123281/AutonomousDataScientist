import React from "react";

function Header() {
  return (
    <header className="app-header">

      <div className="brand">

        <div className="brand-mark">
          A
        </div>

        <div>
          <h1>AutoDS</h1>
          <p>Autonomous Data Scientist</p>
        </div>

      </div>

      <div className="system-status">
        <span className="status-dot"></span>
        System Online
      </div>

    </header>
  );
}

export default Header;