import "./AgentControlCenter.css";

const agents = [
  {
    id: 1,
    icon: "◉",
    name: "Profiling",
    title: "Profiling Agent",
    description:
      "Analyzes dataset structure, schema, data types, missing values and duplicate records.",
    output: "Dataset Profile",
  },
  {
    id: 2,
    icon: "✦",
    name: "Cleaning",
    title: "Cleaning Agent",
    description:
      "Detects and fixes missing values, removes duplicates and prepares clean data.",
    output: "Clean Dataset",
  },
  {
    id: 3,
    icon: "⌁",
    name: "EDA",
    title: "EDA Agent",
    description:
      "Performs statistical analysis and discovers patterns, distributions and correlations.",
    output: "EDA Results",
  },
  {
    id: 4,
    icon: "◇",
    name: "Modeling",
    title: "Modeling Agent",
    description:
      "Automatically trains a machine learning model using suitable numerical features.",
    output: "ML Model",
  },
  {
    id: 5,
    icon: "▥",
    name: "Visualization",
    title: "Visualization Agent",
    description:
      "Creates interactive charts for distributions, relationships, correlations and outliers.",
    output: "Interactive Charts",
  },
  {
    id: 6,
    icon: "✧",
    name: "AI Insights",
    title: "AI Insights Agent",
    description:
      "Interprets analytical results and converts data patterns into understandable insights.",
    output: "AI Insights",
  },
  {
    id: 7,
    icon: "▤",
    name: "Report",
    title: "Report Agent",
    description:
      "Combines all pipeline results into a structured final data science report.",
    output: "Final Report",
  },
];

function AgentControlCenter({ openAgent }) {
  return (
    <section className="agent-center">

      {/* HEADER */}
      <div className="agent-page-header">

        <div>
          <div className="eyebrow">
            AUTODS INTELLIGENCE
          </div>

          <h1>Agent Control Center</h1>

          <p>
            Monitor and inspect every autonomous agent
            responsible for the AutoDS data science workflow.
          </p>
        </div>

        <div className="system-status">
          <span className="status-dot"></span>

          <div>
            <strong>ALL SYSTEMS OPERATIONAL</strong>
            <small>7 autonomous agents online</small>
          </div>
        </div>

      </div>


      {/* ORCHESTRATOR */}
      <div className="orchestrator-card">

        <div className="orchestrator-icon">
          A
        </div>

        <div className="orchestrator-info">

          <span className="orchestrator-label">
            ORCHESTRATOR
          </span>

          <h2>AutoDS Autonomous Controller</h2>

          <p>
            Coordinates all seven agents and manages the
            autonomous data science workflow.
          </p>

        </div>

        <div className="orchestrator-meta">

          <div>
            <span>AGENTS</span>
            <strong>07</strong>
          </div>

          <div>
            <span>STATUS</span>
            <strong className="online-text">ONLINE</strong>
          </div>

          <div>
            <span>MODE</span>
            <strong>AUTONOMOUS</strong>
          </div>

        </div>

      </div>


      {/* SECTION TITLE */}
      <div className="agents-section-heading">

        <div>
          <span className="eyebrow">
            WORKFLOW
          </span>

          <h2>7 Autonomous Agents</h2>
        </div>

        <span className="pipeline-ready">
          ● Pipeline Ready
        </span>

      </div>


      {/* AGENT GRID */}
      <div className="agent-grid">

        {agents.map((agent) => (

          <button
            key={agent.id}
            className="agent-card"
            onClick={() => openAgent(agent)}
          >

            <div className="agent-card-top">

              <div className="agent-icon">
                {agent.icon}
              </div>

              <span className="agent-number">
                AGENT {String(agent.id).padStart(2, "0")}
              </span>

              <span className="agent-check">
                ✓
              </span>

            </div>


            <div className="agent-card-body">

              <h3>
                {agent.title}
              </h3>

              <p>
                {agent.description}
              </p>

            </div>


            <div className="agent-card-footer">

              <div>
                <span>OUTPUT</span>
                <strong>{agent.output}</strong>
              </div>

              <span className="open-arrow">
                →
              </span>

            </div>

          </button>

        ))}

      </div>

    </section>
  );
}

export default AgentControlCenter;