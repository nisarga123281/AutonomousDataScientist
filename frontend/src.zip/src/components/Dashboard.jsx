import UploadSection from "./UploadSection";
import Pipeline from "./Pipeline";

function Dashboard({ setPage, pipelineData, setPipelineData }) {
  return (
    <div className="dashboard-page">

      {/* PAGE HEADER */}
      <section className="dashboard-header">
        <div>
          <div className="eyebrow">
            AUTONOMOUS DATA SCIENCE
          </div>

          <h1>Turn raw data into intelligent insights.</h1>

          <p>
            AutoDS automatically profiles, cleans, explores,
            models, visualizes and explains your dataset using
            an end-to-end autonomous data science workflow.
          </p>
        </div>

        <div className="dashboard-status">
          <span className="status-dot"></span>
          SYSTEM ONLINE
        </div>
      </section>


      {/* UPLOAD */}
      <UploadSection
        setPipelineData={setPipelineData}
      />


      {/* PIPELINE */}
      <Pipeline
        pipelineData={pipelineData}
      />


      {/* AGENT CONTROL CENTER LINK */}
      <section className="dashboard-agents">

        <div>
          <span className="eyebrow">
            AUTODS INTELLIGENCE
          </span>

          <h2>Agent Control Center</h2>

          <p>
            Monitor and inspect the seven autonomous agents
            responsible for the AutoDS workflow.
          </p>
        </div>

        <button
          className="dashboard-agent-button"
          onClick={() => setPage("agents")}
        >
          Open Agent Control Center →
        </button>

      </section>

    </div>
  );
}

export default Dashboard;
