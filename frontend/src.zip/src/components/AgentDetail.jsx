import "./AgentDetail.css";

export default function AgentDetails({
  agent,
  data,
  onClose,
}) {
  if (!agent) return null;

  const renderContent = () => {

    /* =====================================================
       PROFILING
       ===================================================== */

    if (agent.number === "01") {

      const result = data?.phase1 || {};

      return (
        <div className="agent-detail-content">

          <div className="detail-metrics">

            <Metric
              label="Rows"
              value={result.rows ?? "-"}
            />

            <Metric
              label="Columns"
              value={result.columns ?? "-"}
            />

            <Metric
              label="Numerical"
              value={result.numerical_columns?.length ?? 0}
            />

            <Metric
              label="Categorical"
              value={result.categorical_columns?.length ?? 0}
            />

            <Metric
              label="Duplicates"
              value={result.duplicate_rows ?? 0}
            />

          </div>


          <DetailSection title="Dataset Columns">

            <div className="column-list">

              {(result.column_names || []).map(
                (column) => (

                  <div
                    className="column-item"
                    key={column}
                  >
                    <span>{column}</span>

                    <span>
                      {result.data_types?.[column] || "unknown"}
                    </span>
                  </div>

                )
              )}

            </div>

          </DetailSection>


          <DetailSection title="Missing Values">

            <div className="data-table">

              {Object.entries(
                result.missing_values || {}
              ).map(([column, value]) => (

                <div
                  className="table-row"
                  key={column}
                >

                  <span>{column}</span>

                  <strong>
                    {value}
                  </strong>

                </div>

              ))}

            </div>

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       CLEANING
       ===================================================== */

    if (agent.number === "02") {

      const result = data?.phase2 || {};

      return (
        <div className="agent-detail-content">

          <div className="detail-metrics">

            <Metric
              label="Original Rows"
              value={result.original_rows ?? "-"}
            />

            <Metric
              label="Cleaned Rows"
              value={result.cleaned_rows ?? "-"}
            />

            <Metric
              label="Duplicates Removed"
              value={result.duplicates_removed ?? 0}
            />

            <Metric
              label="Missing Before"
              value={result.missing_values_before ?? 0}
            />

            <Metric
              label="Missing After"
              value={result.missing_values_after ?? 0}
            />

          </div>


          <DetailSection title="Cleaning Operations">

            <Operation
              title="Duplicate Detection"
              value={
                `${result.duplicates_removed ?? 0} duplicate rows removed`
              }
            />

            <Operation
              title="Missing Value Treatment"
              value={
                `${result.missing_values_before ?? 0} missing values detected`
              }
            />

            <Operation
              title="Clean Dataset"
              value={
                `${result.cleaned_rows ?? 0} rows available for analysis`
              }
            />

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       EDA
       ===================================================== */

    if (agent.number === "03") {

      const result = data?.phase3 || {};

      return (
        <div className="agent-detail-content">

          <div className="detail-metrics">

            <Metric
              label="Rows"
              value={result.rows ?? "-"}
            />

            <Metric
              label="Columns"
              value={result.columns ?? "-"}
            />

            <Metric
              label="Numerical"
              value={result.numerical_columns?.length ?? 0}
            />

            <Metric
              label="Categorical"
              value={result.categorical_columns?.length ?? 0}
            />

          </div>


          <DetailSection title="Numerical Statistics">

            <div className="stats-table">

              <div className="stats-header">

                <span>Column</span>
                <span>Mean</span>
                <span>Median</span>
                <span>Min</span>
                <span>Max</span>

              </div>


              {Object.entries(
                result.statistics || {}
              ).map(([column, stats]) => (

                <div
                  className="stats-row"
                  key={column}
                >

                  <strong>{column}</strong>

                  <span>
                    {Number(stats.mean).toFixed(2)}
                  </span>

                  <span>
                    {Number(stats.median).toFixed(2)}
                  </span>

                  <span>
                    {Number(stats.minimum).toFixed(2)}
                  </span>

                  <span>
                    {Number(stats.maximum).toFixed(2)}
                  </span>

                </div>

              ))}

            </div>

          </DetailSection>


          <DetailSection title="Correlation Matrix">

            <pre className="json-box">
              {JSON.stringify(
                result.correlation || {},
                null,
                2
              )}
            </pre>

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       MODELING
       ===================================================== */

    if (agent.number === "04") {

      const result = data?.phase4 || {};

      if (!result.algorithm) {

        return (
          <EmptyState
            message="Modeling could not be performed because the dataset does not contain enough numerical columns."
          />
        );
      }

      return (
        <div className="agent-detail-content">

          <div className="model-banner">

            <span>MODEL</span>

            <strong>
              {result.algorithm}
            </strong>

          </div>


          <div className="model-flow">

            <div className="model-node">

              <small>FEATURE</small>

              <strong>
                {result.feature}
              </strong>

            </div>

            <div className="model-arrow">
              →
            </div>

            <div className="model-node">

              <small>TARGET</small>

              <strong>
                {result.target}
              </strong>

            </div>

          </div>


          <div className="detail-metrics">

            <Metric
              label="Training Rows"
              value={result.training_rows}
            />

            <Metric
              label="Testing Rows"
              value={result.testing_rows}
            />

            <Metric
              label="MAE"
              value={Number(result.mae).toFixed(3)}
            />

            <Metric
              label="RMSE"
              value={Number(result.rmse).toFixed(3)}
            />

            <Metric
              label="R² Score"
              value={Number(result.r2_score).toFixed(3)}
              highlight
            />

          </div>


          <DetailSection title="Model Equation">

            <div className="equation">

              {result.target} ={" "}

              {Number(result.coefficient).toFixed(3)}

              {" × "}

              {result.feature}

              {" "}

              {result.intercept >= 0
                ? "+"
                : "-"
              }

              {" "}

              {Math.abs(
                Number(result.intercept)
              ).toFixed(3)}

            </div>

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       VISUALIZATION
       ===================================================== */

    if (agent.number === "05") {

      const result = data?.phase5 || {};

      return (
        <div className="agent-detail-content">

          <div className="detail-metrics">

            <Metric
              label="Library"
              value={result.library || "Plotly"}
            />

            <Metric
              label="Charts"
              value={result.plots_generated ?? 0}
            />

            <Metric
              label="Interactive"
              value="Yes"
            />

          </div>


          <DetailSection title="Generated Visualizations">

            <div className="visualization-list">

              {(result.generated_plots || []).map(
                (plot, index) => (

                  <a
                    className="visualization-item"
                    href={`http://127.0.0.1:8000${plot.url}`}
                    target="_blank"
                    rel="noreferrer"
                    key={plot.name}
                  >

                    <div>

                      <span className="plot-number">
                        {String(index + 1).padStart(2, "0")}
                      </span>

                      <strong>
                        {plot.name}
                      </strong>

                    </div>

                    <span>
                      {plot.type}
                    </span>

                    <b>↗</b>

                  </a>

                )
              )}

            </div>

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       AI INSIGHTS
       ===================================================== */

    if (agent.number === "06") {

      const result = data?.phase6 || {};

      return (
        <div className="agent-detail-content">

          <div className="correlation-highlight">

            <small>
              PRIMARY CORRELATION
            </small>

            <strong>
              {result.correlation != null
                ? Number(
                    result.correlation
                  ).toFixed(4)
                : "N/A"
              }
            </strong>

            <span>
              Correlation coefficient
            </span>

          </div>


          <DetailSection title="Generated Insights">

            <div className="insight-list">

              {(result.insights || []).map(
                (insight, index) => (

                  <div
                    className="insight-item"
                    key={index}
                  >

                    <span>
                      {String(index + 1).padStart(2, "0")}
                    </span>

                    <p>
                      {insight}
                    </p>

                  </div>

                )
              )}

            </div>

          </DetailSection>

        </div>
      );
    }


    /* =====================================================
       REPORT
       ===================================================== */

    if (agent.number === "07") {

      const result = data?.phase7 || {};

      return (
        <div className="agent-detail-content">

          <div className="report-success">

            <div className="report-icon">
              ▤
            </div>

            <div>

              <small>
                REPORT GENERATED
              </small>

              <h3>
                AutoDS Final Report
              </h3>

              <p>
                Complete automated data science
                analysis report.
              </p>

            </div>

          </div>


          <a
            className="report-button"
            href="http://127.0.0.1:8000/reports/autods_final_report.txt"
            target="_blank"
            rel="noreferrer"
          >
            View Final Report →
          </a>


          <DetailSection title="Report Contents">

            <div className="report-items">

              <span>✓ Dataset Overview</span>
              <span>✓ Data Quality Analysis</span>
              <span>✓ Cleaning Summary</span>
              <span>✓ Exploratory Data Analysis</span>
              <span>✓ Machine Learning Results</span>
              <span>✓ Visualization Summary</span>
              <span>✓ AI Insights</span>
              <span>✓ Recommendations</span>

            </div>

          </DetailSection>

        </div>
      );
    }


    return (
      <EmptyState
        message="Agent details are not available."
      />
    );
  };


  return (
    <div
      className="agent-modal-overlay"
      onClick={onClose}
    >

      <div
        className="agent-modal"
        onClick={(e) => e.stopPropagation()}
      >

        <div className="agent-modal-header">

          <div className="agent-modal-title">

            <div className="large-agent-icon">
              {agent.icon}
            </div>

            <div>

              <span>
                PHASE {agent.number}
              </span>

              <h2>
                {agent.name}
              </h2>

              <p>
                {agent.description}
              </p>

            </div>

          </div>


          <button
            className="close-button"
            onClick={onClose}
          >
            ×
          </button>

        </div>


        <div className="agent-running-bar">

          <span className="running-dot"></span>

          Agent completed successfully

          <span className="agent-time">
            AUTONOMOUS EXECUTION
          </span>

        </div>


        {renderContent()}

      </div>

    </div>
  );
}


/* =========================================================
   SMALL COMPONENTS
   ========================================================= */

function Metric({
  label,
  value,
  highlight = false,
}) {

  return (

    <div
      className={`detail-metric ${
        highlight ? "highlight" : ""
      }`}
    >

      <span>
        {label}
      </span>

      <strong>
        {value}
      </strong>

    </div>
  );
}


function DetailSection({
  title,
  children,
}) {

  return (

    <div className="detail-section">

      <h3>
        {title}
      </h3>

      {children}

    </div>
  );
}


function Operation({
  title,
  value,
}) {

  return (

    <div className="operation">

      <div className="operation-check">
        ✓
      </div>

      <div>

        <strong>
          {title}
        </strong>

        <span>
          {value}
        </span>

      </div>

    </div>
  );
}


function EmptyState({
  message,
}) {

  return (

    <div className="empty-agent">
      {message}
    </div>
  );
}
